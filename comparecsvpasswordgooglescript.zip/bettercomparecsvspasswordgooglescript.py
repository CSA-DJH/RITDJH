import csv
import time
import re

f2 = open('CURRENTACCTS.csv', 'r')
f1 = open('CURRENTSTUDENTS.csv', 'r')
f3 = open('results.csv', 'w',newline='')

googleaccounts=csv.reader(f1)
googlelist=list(googleaccounts)
students=csv.reader(f2)
write=csv.writer(f3)

host_rowgetnum=0 #change host_row to the corresponding row - 1 (ie; row 45, put in 44) in google's csv
google_rowgetnum=0 #master_row to the schools student list
for hosts_row in students:
    row = 1
    found = False
    for google_row in googlelist:
        results_row = hosts_row
        google_row[google_rowgetnum]=google_row[google_rowgetnum].replace("@chaparralstaracademy.com","")
        hosts_row[host_rowgetnum]=hosts_row[host_rowgetnum].replace("@chaparralstaracademy.com","")
        google_row[google_rowgetnum]=google_row[google_rowgetnum].zfill(4)
        hosts_row[host_rowgetnum]=hosts_row[host_rowgetnum].zfill(4)
        #print(hosts_row,google_row)
        #time.sleep(.01)
        if hosts_row[host_rowgetnum].lower() == google_row[google_rowgetnum].lower(): 
            found = True
            print()
            print(found)
            print()
            break
        row = row + 1
    if found != True:
        write.writerow(results_row) #only adds row if the person is in the list, otherwise keeps it clear
f1.close()
f2.close()
f3.close()
print("done")
